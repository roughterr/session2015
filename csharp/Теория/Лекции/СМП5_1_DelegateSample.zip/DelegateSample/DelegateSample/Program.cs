using System;
using System.Collections.Generic;

namespace DelegateSample
{
	class MainClass
	{
		delegate void MyDelegate(string stx);

		static void replaceSpaces(string a) 
		{
			Console.WriteLine("Замена пробелов дефисами.");
			Console.WriteLine(a.Replace(' ', '-'));
		}

		static void removeSpaces(string a) 
		{
			Console.WriteLine("Удаление пробелов.");
			Console.WriteLine(a.Replace(' ', '\0' ));
		}

		static void reverse(string a) 
		{
			Console.WriteLine("Обратный порядок символов.");
			List<Char> listc = new List<Char>();
			listc.AddRange(a.ToCharArray());
			listc.Reverse();
			foreach(Char c in listc)
			Console.Write("{0}", c);
		}

		public static void Main (string[] args)
		{
			MyDelegate strOp;
			MyDelegate replaceSp =new MyDelegate(replaceSpaces);
			MyDelegate removeSp = new MyDelegate(removeSpaces);
			MyDelegate reverseStr = new MyDelegate(reverse);
			strOp = replaceSp;
			strOp += removeSp;
				
			strOp("Простой тест.");
			strOp -= removeSp;
			strOp += reverseStr;
			strOp("Простой тест.");
			Console.ReadKey ();
		}
	}
}
