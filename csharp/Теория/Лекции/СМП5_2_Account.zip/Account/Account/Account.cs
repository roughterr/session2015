using System;

namespace Account
{
	class Account
	{
		// Объявляем делегат
		public delegate void AccountStateHandler(string message);
		// Событие, возникающее при выводе денег
		public event AccountStateHandler Withdrowed;
		// Событие, возникающее при добавление на счет
		public event AccountStateHandler Added;

		int _sum; // Переменная для хранения суммы
		int _percentage; // Переменная для хранения процента

		public Account(int sum, int percentage)
		{
			_sum = sum;
			_percentage = percentage;
		}

		public int CurrentSum
		{
			get { return _sum; }
		}

		public void Put(int sum)
		{
			_sum += sum;
			if (Added != null)
				Added("На счет поступило " + sum);
		}
		public void Withdraw(int sum)
		{
			if (sum <= _sum)
			{
				_sum -= sum;
				if (Withdrowed != null)
					Withdrowed("Сумма " + sum + " снята со счета");
			}
			else
			{
				if (Withdrowed != null)
					Withdrowed("Недостаточно денег на счете");
			}
		}

		public int Percentage
		{
			get { return _percentage; }
		}
	}
}

