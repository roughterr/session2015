using System;

namespace GarbageColector
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			System.Console.WriteLine ("TotalMemorym #1 is {0}", GC.GetTotalMemory(false));
			Console.WriteLine ("MaxGeneration #1 {0}", GC.MaxGeneration);
			MainClass ob = new MainClass ();
			ob.createObjects ();
			Console.WriteLine ("Generation #1: {0}", GC.GetGeneration(ob));
			System.Console.WriteLine ("TotalMemorym #2 is {0}", GC.GetTotalMemory(false));
			GC.Collect (1);
			GC.CollectionCount (0);
			Console.WriteLine ("Generation #2: {0}", GC.GetGeneration(ob));
			System.Console.WriteLine ("TotalMemorym #3 is {0}", GC.GetTotalMemory(false));
			GC.Collect (2);
			Console.WriteLine ("Generation #3: {0}", GC.GetGeneration(ob));
			System.Console.WriteLine ("TotalMemorym #4 is {0}", GC.GetTotalMemory(false));
		}
		public void createObjects(){
			Trashhh[] obj = new Trashhh[100];
			for (int i = 0; i < 100; i++) {
				obj[i] = new Trashhh (i);

			}
		}
	}
}
