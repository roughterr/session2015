using System;

namespace GarbageColector
{
	public class Trashhh
	{
		private int number;

		public Trashhh (int numb)
		{
			number = numb;
			Console.WriteLine ("I'm Constructor for object. My number is {0}. Generation {1}", number, GC.GetGeneration (this));

		}

		~Trashhh(){
			Console.WriteLine ("I'm destructor for objec. My number is {0}. Generation {1}", number, GC.GetGeneration (this));
		}
	}
}

